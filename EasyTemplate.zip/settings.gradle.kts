pluginManagement {
    repositories {
        maven("https://maven.xbaimiao.com/repository/maven-public/")
        google()
        mavenCentral()
        gradlePluginPortal()
        maven("https://repo.papermc.io/repository/maven-public/")
    }
}
rootProject.name = "EasyTemplate"
